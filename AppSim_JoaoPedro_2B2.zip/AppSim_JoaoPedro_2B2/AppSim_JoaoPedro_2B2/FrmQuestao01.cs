﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSim_JoaoPedro_2B2
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double valorKwh = double.Parse(txtValorKwh.Text);
            double consumo = double.Parse(txtConsumo.Text);
            double diasEmAtraso = double.Parse(txtAtraso.Text);
            double valorDaConta;
           double valorJuros = 0.015;
            double valorFinal;

            valorDaConta = valorKwh * consumo;

            valorFinal = Math.Pow((valorDaConta * (1 + valorJuros)diasEmAtraso),));

            txtValorPagar.Text = valorFinal.ToString();

        }
    }
}