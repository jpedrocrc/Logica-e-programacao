﻿namespace AppSim_JoaoPedro_2B2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEndereco = new System.Windows.Forms.Label();
            this.lblValorKwh = new System.Windows.Forms.Label();
            this.lblConsumo = new System.Windows.Forms.Label();
            this.lblAtraso = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtValorKwh = new System.Windows.Forms.TextBox();
            this.txtConsumo = new System.Windows.Forms.TextBox();
            this.txtValorPagar = new System.Windows.Forms.TextBox();
            this.txtAtraso = new System.Windows.Forms.TextBox();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.Location = new System.Drawing.Point(15, 38);
            this.lblEndereco.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(94, 24);
            this.lblEndereco.TabIndex = 0;
            this.lblEndereco.Text = "Endereco";
            // 
            // lblValorKwh
            // 
            this.lblValorKwh.AutoSize = true;
            this.lblValorKwh.Location = new System.Drawing.Point(11, 74);
            this.lblValorKwh.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblValorKwh.Name = "lblValorKwh";
            this.lblValorKwh.Size = new System.Drawing.Size(100, 24);
            this.lblValorKwh.TabIndex = 1;
            this.lblValorKwh.Text = "Valor KWh";
            // 
            // lblConsumo
            // 
            this.lblConsumo.AutoSize = true;
            this.lblConsumo.Location = new System.Drawing.Point(11, 116);
            this.lblConsumo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblConsumo.Name = "lblConsumo";
            this.lblConsumo.Size = new System.Drawing.Size(190, 24);
            this.lblConsumo.TabIndex = 2;
            this.lblConsumo.Text = "Consumo de Energia";
            // 
            // lblAtraso
            // 
            this.lblAtraso.AutoSize = true;
            this.lblAtraso.Location = new System.Drawing.Point(11, 160);
            this.lblAtraso.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAtraso.Name = "lblAtraso";
            this.lblAtraso.Size = new System.Drawing.Size(136, 24);
            this.lblAtraso.TabIndex = 3;
            this.lblAtraso.Text = "Dias em Atraso";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 273);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Valor à Pagar";
            // 
            // txtValorKwh
            // 
            this.txtValorKwh.Location = new System.Drawing.Point(207, 71);
            this.txtValorKwh.Margin = new System.Windows.Forms.Padding(6);
            this.txtValorKwh.Name = "txtValorKwh";
            this.txtValorKwh.Size = new System.Drawing.Size(180, 29);
            this.txtValorKwh.TabIndex = 5;
            // 
            // txtConsumo
            // 
            this.txtConsumo.Location = new System.Drawing.Point(207, 117);
            this.txtConsumo.Margin = new System.Windows.Forms.Padding(6);
            this.txtConsumo.Name = "txtConsumo";
            this.txtConsumo.Size = new System.Drawing.Size(180, 29);
            this.txtConsumo.TabIndex = 6;
            // 
            // txtValorPagar
            // 
            this.txtValorPagar.Location = new System.Drawing.Point(146, 270);
            this.txtValorPagar.Margin = new System.Windows.Forms.Padding(6);
            this.txtValorPagar.Name = "txtValorPagar";
            this.txtValorPagar.Size = new System.Drawing.Size(180, 29);
            this.txtValorPagar.TabIndex = 7;
            // 
            // txtAtraso
            // 
            this.txtAtraso.Location = new System.Drawing.Point(207, 158);
            this.txtAtraso.Margin = new System.Windows.Forms.Padding(6);
            this.txtAtraso.Name = "txtAtraso";
            this.txtAtraso.Size = new System.Drawing.Size(180, 29);
            this.txtAtraso.TabIndex = 8;
            // 
            // txtEndereco
            // 
            this.txtEndereco.Location = new System.Drawing.Point(207, 35);
            this.txtEndereco.Margin = new System.Windows.Forms.Padding(6);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(180, 29);
            this.txtEndereco.TabIndex = 9;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnCalcular.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCalcular.Location = new System.Drawing.Point(-5, 199);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(401, 45);
            this.btnCalcular.TabIndex = 10;
            this.btnCalcular.Text = "Calcular Valor à Pagar";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(403, 326);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtEndereco);
            this.Controls.Add(this.txtAtraso);
            this.Controls.Add(this.txtValorPagar);
            this.Controls.Add(this.txtConsumo);
            this.Controls.Add(this.txtValorKwh);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblAtraso);
            this.Controls.Add(this.lblConsumo);
            this.Controls.Add(this.lblValorKwh);
            this.Controls.Add(this.lblEndereco);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.Label lblValorKwh;
        private System.Windows.Forms.Label lblConsumo;
        private System.Windows.Forms.Label lblAtraso;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtValorKwh;
        private System.Windows.Forms.TextBox txtConsumo;
        private System.Windows.Forms.TextBox txtValorPagar;
        private System.Windows.Forms.TextBox txtAtraso;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.Button btnCalcular;
    }
}

