﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSim_JoaoPedro_2B2
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtValor1.Text);
            float valor2 = float.Parse(txtValor2.Text);
            float valor3 = float.Parse(txtValor3.Text);
            double CalcularV1;
            double CalcularV2;
            double CalcularV3;

            CalcularV1 = valor1 + (valor1 * 0.10);
            CalcularV2 = valor2 + (valor2 * 0.10);
            CalcularV3 = valor3 + (valor3 * 0.10);

            txtRValor1.Text = CalcularV1.ToString();
            txtRValor2.Text = CalcularV2.ToString();
            txtRValor3.Text = CalcularV3.ToString();

        }
    }
}
