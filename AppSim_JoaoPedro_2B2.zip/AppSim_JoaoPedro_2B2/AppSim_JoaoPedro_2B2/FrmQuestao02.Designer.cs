﻿namespace AppSim_JoaoPedro_2B2
{
    partial class FrmQuestao02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtRValor1 = new System.Windows.Forms.TextBox();
            this.txtRValor2 = new System.Windows.Forms.TextBox();
            this.txtValor1 = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtValor2 = new System.Windows.Forms.TextBox();
            this.txtValor3 = new System.Windows.Forms.TextBox();
            this.txtRValor3 = new System.Windows.Forms.TextBox();
            this.lblValor1 = new System.Windows.Forms.Label();
            this.lblValor2 = new System.Windows.Forms.Label();
            this.lblValor3 = new System.Windows.Forms.Label();
            this.lblRValor1 = new System.Windows.Forms.Label();
            this.lblRValor2 = new System.Windows.Forms.Label();
            this.lblRValor3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtRValor1
            // 
            this.txtRValor1.Location = new System.Drawing.Point(176, 225);
            this.txtRValor1.Name = "txtRValor1";
            this.txtRValor1.Size = new System.Drawing.Size(100, 29);
            this.txtRValor1.TabIndex = 0;
            // 
            // txtRValor2
            // 
            this.txtRValor2.Location = new System.Drawing.Point(176, 263);
            this.txtRValor2.Name = "txtRValor2";
            this.txtRValor2.Size = new System.Drawing.Size(100, 29);
            this.txtRValor2.TabIndex = 1;
            // 
            // txtValor1
            // 
            this.txtValor1.Location = new System.Drawing.Point(176, 9);
            this.txtValor1.Name = "txtValor1";
            this.txtValor1.Size = new System.Drawing.Size(100, 29);
            this.txtValor1.TabIndex = 2;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(12, 168);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(307, 35);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtValor2
            // 
            this.txtValor2.Location = new System.Drawing.Point(176, 55);
            this.txtValor2.Name = "txtValor2";
            this.txtValor2.Size = new System.Drawing.Size(100, 29);
            this.txtValor2.TabIndex = 4;
            // 
            // txtValor3
            // 
            this.txtValor3.Location = new System.Drawing.Point(176, 108);
            this.txtValor3.Name = "txtValor3";
            this.txtValor3.Size = new System.Drawing.Size(100, 29);
            this.txtValor3.TabIndex = 5;
            // 
            // txtRValor3
            // 
            this.txtRValor3.Location = new System.Drawing.Point(176, 301);
            this.txtRValor3.Name = "txtRValor3";
            this.txtRValor3.Size = new System.Drawing.Size(100, 29);
            this.txtRValor3.TabIndex = 6;
            // 
            // lblValor1
            // 
            this.lblValor1.AutoSize = true;
            this.lblValor1.Location = new System.Drawing.Point(12, 9);
            this.lblValor1.Name = "lblValor1";
            this.lblValor1.Size = new System.Drawing.Size(131, 24);
            this.lblValor1.TabIndex = 7;
            this.lblValor1.Text = "Insire o valor 1";
            // 
            // lblValor2
            // 
            this.lblValor2.AutoSize = true;
            this.lblValor2.Location = new System.Drawing.Point(12, 55);
            this.lblValor2.Name = "lblValor2";
            this.lblValor2.Size = new System.Drawing.Size(131, 24);
            this.lblValor2.TabIndex = 8;
            this.lblValor2.Text = "Insire o valor 2";
            // 
            // lblValor3
            // 
            this.lblValor3.AutoSize = true;
            this.lblValor3.Location = new System.Drawing.Point(12, 113);
            this.lblValor3.Name = "lblValor3";
            this.lblValor3.Size = new System.Drawing.Size(131, 24);
            this.lblValor3.TabIndex = 9;
            this.lblValor3.Text = "Insire o valor 3";
            // 
            // lblRValor1
            // 
            this.lblRValor1.AutoSize = true;
            this.lblRValor1.Location = new System.Drawing.Point(12, 225);
            this.lblRValor1.Name = "lblRValor1";
            this.lblRValor1.Size = new System.Drawing.Size(158, 24);
            this.lblRValor1.TabIndex = 10;
            this.lblRValor1.Text = "Resultado Valor 1";
            // 
            // lblRValor2
            // 
            this.lblRValor2.AutoSize = true;
            this.lblRValor2.Location = new System.Drawing.Point(12, 261);
            this.lblRValor2.Name = "lblRValor2";
            this.lblRValor2.Size = new System.Drawing.Size(158, 24);
            this.lblRValor2.TabIndex = 11;
            this.lblRValor2.Text = "Resultado Valor 2";
            // 
            // lblRValor3
            // 
            this.lblRValor3.AutoSize = true;
            this.lblRValor3.Location = new System.Drawing.Point(12, 301);
            this.lblRValor3.Name = "lblRValor3";
            this.lblRValor3.Size = new System.Drawing.Size(158, 24);
            this.lblRValor3.TabIndex = 12;
            this.lblRValor3.Text = "Resultado Valor 3";
            // 
            // FrmQuestao02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 396);
            this.Controls.Add(this.lblRValor3);
            this.Controls.Add(this.lblRValor2);
            this.Controls.Add(this.lblRValor1);
            this.Controls.Add(this.lblValor3);
            this.Controls.Add(this.lblValor2);
            this.Controls.Add(this.lblValor1);
            this.Controls.Add(this.txtRValor3);
            this.Controls.Add(this.txtValor3);
            this.Controls.Add(this.txtValor2);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtValor1);
            this.Controls.Add(this.txtRValor2);
            this.Controls.Add(this.txtRValor1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FrmQuestao02";
            this.Text = "FrmQuestao02";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRValor1;
        private System.Windows.Forms.TextBox txtRValor2;
        private System.Windows.Forms.TextBox txtValor1;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtValor2;
        private System.Windows.Forms.TextBox txtValor3;
        private System.Windows.Forms.TextBox txtRValor3;
        private System.Windows.Forms.Label lblValor1;
        private System.Windows.Forms.Label lblValor2;
        private System.Windows.Forms.Label lblValor3;
        private System.Windows.Forms.Label lblRValor1;
        private System.Windows.Forms.Label lblRValor2;
        private System.Windows.Forms.Label lblRValor3;
    }
}