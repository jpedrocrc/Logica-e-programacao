﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalc
{
   

        public partial class FrmCalculadora : Form
        {

            public FrmCalculadora()
            {
                InitializeComponent();
				MessageBox.Show("Calculadora iniciada");
            }

       

        private void btnIgual_Click(object sender, EventArgs e)
        {
            txtIgual.Text = "=";
            txtResultado.Text = calcula().ToString();
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            preencheAcao("+");
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            preencheAcao("-");
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            preencheAcao("x");
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            preencheAcao("/");
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click no Botão Porcentagem");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            limpaVisor();
        }

        private void btnNumero1_Click(object sender, EventArgs e)
        {
            preencheVisor("1");
        }

        private void btnNumero2_Click(object sender, EventArgs e)
        {
            preencheVisor("2");
        }

        private void btnNumero3_Click(object sender, EventArgs e)
        {
            preencheVisor("3");
        }

        private void btnNumero4_Click(object sender, EventArgs e)
        {
            preencheVisor("4");
        }

        private void btnNumero5_Click(object sender, EventArgs e)
        {
            preencheVisor("5");
        }

        private void btnNumero6_Click(object sender, EventArgs e)
        {
            preencheVisor("6");
        }

        private void btnNumero7_Click(object sender, EventArgs e)
        {
            preencheVisor("7");
        }

        private void btnNumero8_Click(object sender, EventArgs e)
        {
            preencheVisor("8");
        }

        private void btnNumero9_Click(object sender, EventArgs e)
        {
            preencheVisor("9");
        }
        private void btnNumero0_Click(object sender, EventArgs e)
        {
            preencheVisor("0");
        }
        private void btnVirgula_Click(object sender, EventArgs e)
        {
            preencheVisor(",");
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            corrigeConteudo();
        }

        private void FrmCalculadora_Load(object sender, EventArgs e)
        {

        }
        private void preencheVisor(string conteudo)
        {
            if (txtAcao.Text == "")
            {
                txtOperador1.Text = txtOperador1.Text + conteudo;
            }else
            {
                txtOperador2.Text = txtOperador2.Text + conteudo;
            }
        }

        private void preencheAcao(string conteudo)
        {
            txtAcao.Text = conteudo;
        }
        private void limpaVisor()
        {
            txtOperador1.Text = "";
            txtAcao.Text = "";
            txtOperador2.Text = "";
            txtIgual.Text = "";
            txtResultado.Text = "";

         
        }
        private void corrigeConteudo()
        {
            if (txtResultado.Text != "")
            {
                txtIgual.Text = "";
                txtResultado.Text = "";
            }
            else if (txtOperador2.Text != "")
            {
                txtOperador2.Text = "";
            }
            else if (txtAcao.Text != "")
            {
                txtAcao.Text = "";
            }
            else if (txtOperador1.Text != "")
            {
                txtOperador1.Text = "";
            }
        }

        public decimal calcula()
        {
            decimal campo1 = Convert.ToDecimal(txtOperador1.Text); 
            decimal campo2 = Convert.ToDecimal(txtOperador2.Text);
            string operacao = txtAcao.Text;
            if (operacao == "+")
            {
                return campo1 + campo2;
            }
            if (operacao == "-")
            {
                return campo1 - campo2;
            }
            if (operacao == "x")
            {
                return campo1 * campo2;
            }
            if (operacao == "/")
            {
                return campo1 / campo2;
            }
            return 0;
        }
    }
} 


