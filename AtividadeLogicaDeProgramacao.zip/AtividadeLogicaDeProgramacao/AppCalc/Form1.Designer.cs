﻿namespace AppCalc
{
    partial class FrmCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCalculadora));
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.btnMultiplicacao = new System.Windows.Forms.Button();
            this.btnSubtracao = new System.Windows.Forms.Button();
            this.btnAdicao = new System.Windows.Forms.Button();
            this.btnNumero2 = new System.Windows.Forms.Button();
            this.btnNumero3 = new System.Windows.Forms.Button();
            this.btnNumero4 = new System.Windows.Forms.Button();
            this.btnNumero5 = new System.Windows.Forms.Button();
            this.btnNumero6 = new System.Windows.Forms.Button();
            this.btnNumero7 = new System.Windows.Forms.Button();
            this.btnNumero0 = new System.Windows.Forms.Button();
            this.btnNumero8 = new System.Windows.Forms.Button();
            this.btnVirgula = new System.Windows.Forms.Button();
            this.btnApagar = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.btnDivisao = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnNumero1 = new System.Windows.Forms.Button();
            this.btnNumero9 = new System.Windows.Forms.Button();
            this.txtOperador1 = new System.Windows.Forms.TextBox();
            this.txtAcao = new System.Windows.Forms.TextBox();
            this.txtOperador2 = new System.Windows.Forms.TextBox();
            this.txtIgual = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnPorcentagem.Enabled = false;
            this.btnPorcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPorcentagem.ForeColor = System.Drawing.Color.Red;
            this.btnPorcentagem.Location = new System.Drawing.Point(71, 136);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(75, 50);
            this.btnPorcentagem.TabIndex = 1;
            this.btnPorcentagem.Text = "%";
            this.btnPorcentagem.UseVisualStyleBackColor = false;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // btnMultiplicacao
            // 
            this.btnMultiplicacao.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnMultiplicacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplicacao.ForeColor = System.Drawing.Color.Red;
            this.btnMultiplicacao.Location = new System.Drawing.Point(210, 136);
            this.btnMultiplicacao.Name = "btnMultiplicacao";
            this.btnMultiplicacao.Size = new System.Drawing.Size(75, 52);
            this.btnMultiplicacao.TabIndex = 3;
            this.btnMultiplicacao.Text = "X";
            this.btnMultiplicacao.UseVisualStyleBackColor = false;
            this.btnMultiplicacao.Click += new System.EventHandler(this.btnMultiplicacao_Click);
            // 
            // btnSubtracao
            // 
            this.btnSubtracao.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSubtracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubtracao.ForeColor = System.Drawing.Color.Red;
            this.btnSubtracao.Location = new System.Drawing.Point(210, 183);
            this.btnSubtracao.Name = "btnSubtracao";
            this.btnSubtracao.Size = new System.Drawing.Size(75, 52);
            this.btnSubtracao.TabIndex = 16;
            this.btnSubtracao.Text = "-";
            this.btnSubtracao.UseVisualStyleBackColor = false;
            this.btnSubtracao.Click += new System.EventHandler(this.btnSubtracao_Click);
            // 
            // btnAdicao
            // 
            this.btnAdicao.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnAdicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicao.ForeColor = System.Drawing.Color.Red;
            this.btnAdicao.Location = new System.Drawing.Point(210, 229);
            this.btnAdicao.Name = "btnAdicao";
            this.btnAdicao.Size = new System.Drawing.Size(75, 52);
            this.btnAdicao.TabIndex = 17;
            this.btnAdicao.Text = "+";
            this.btnAdicao.UseVisualStyleBackColor = false;
            this.btnAdicao.Click += new System.EventHandler(this.btnAdicao_Click);
            // 
            // btnNumero2
            // 
            this.btnNumero2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero2.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero2.Location = new System.Drawing.Point(71, 183);
            this.btnNumero2.Name = "btnNumero2";
            this.btnNumero2.Size = new System.Drawing.Size(75, 50);
            this.btnNumero2.TabIndex = 20;
            this.btnNumero2.Text = "2";
            this.btnNumero2.UseVisualStyleBackColor = false;
            this.btnNumero2.Click += new System.EventHandler(this.btnNumero2_Click);
            // 
            // btnNumero3
            // 
            this.btnNumero3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero3.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero3.Location = new System.Drawing.Point(142, 183);
            this.btnNumero3.Name = "btnNumero3";
            this.btnNumero3.Size = new System.Drawing.Size(75, 50);
            this.btnNumero3.TabIndex = 21;
            this.btnNumero3.Text = "3";
            this.btnNumero3.UseVisualStyleBackColor = false;
            this.btnNumero3.Click += new System.EventHandler(this.btnNumero3_Click);
            // 
            // btnNumero4
            // 
            this.btnNumero4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero4.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero4.Location = new System.Drawing.Point(0, 229);
            this.btnNumero4.Name = "btnNumero4";
            this.btnNumero4.Size = new System.Drawing.Size(75, 50);
            this.btnNumero4.TabIndex = 22;
            this.btnNumero4.Text = "4";
            this.btnNumero4.UseVisualStyleBackColor = false;
            this.btnNumero4.Click += new System.EventHandler(this.btnNumero4_Click);
            // 
            // btnNumero5
            // 
            this.btnNumero5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero5.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero5.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero5.Location = new System.Drawing.Point(71, 229);
            this.btnNumero5.Name = "btnNumero5";
            this.btnNumero5.Size = new System.Drawing.Size(75, 50);
            this.btnNumero5.TabIndex = 23;
            this.btnNumero5.Text = "5";
            this.btnNumero5.UseVisualStyleBackColor = false;
            this.btnNumero5.Click += new System.EventHandler(this.btnNumero5_Click);
            // 
            // btnNumero6
            // 
            this.btnNumero6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero6.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero6.Location = new System.Drawing.Point(142, 229);
            this.btnNumero6.Name = "btnNumero6";
            this.btnNumero6.Size = new System.Drawing.Size(75, 50);
            this.btnNumero6.TabIndex = 24;
            this.btnNumero6.Text = "6";
            this.btnNumero6.UseVisualStyleBackColor = false;
            this.btnNumero6.Click += new System.EventHandler(this.btnNumero6_Click);
            // 
            // btnNumero7
            // 
            this.btnNumero7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero7.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero7.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero7.Location = new System.Drawing.Point(0, 275);
            this.btnNumero7.Name = "btnNumero7";
            this.btnNumero7.Size = new System.Drawing.Size(75, 50);
            this.btnNumero7.TabIndex = 25;
            this.btnNumero7.Text = "7";
            this.btnNumero7.UseVisualStyleBackColor = false;
            this.btnNumero7.Click += new System.EventHandler(this.btnNumero7_Click);
            // 
            // btnNumero0
            // 
            this.btnNumero0.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero0.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero0.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero0.Location = new System.Drawing.Point(0, 315);
            this.btnNumero0.Name = "btnNumero0";
            this.btnNumero0.Size = new System.Drawing.Size(75, 50);
            this.btnNumero0.TabIndex = 26;
            this.btnNumero0.Text = "0";
            this.btnNumero0.UseVisualStyleBackColor = false;
            this.btnNumero0.Click += new System.EventHandler(this.btnNumero0_Click);
            // 
            // btnNumero8
            // 
            this.btnNumero8.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero8.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero8.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero8.Location = new System.Drawing.Point(71, 275);
            this.btnNumero8.Name = "btnNumero8";
            this.btnNumero8.Size = new System.Drawing.Size(75, 50);
            this.btnNumero8.TabIndex = 27;
            this.btnNumero8.Text = "8";
            this.btnNumero8.UseVisualStyleBackColor = false;
            this.btnNumero8.Click += new System.EventHandler(this.btnNumero8_Click);
            // 
            // btnVirgula
            // 
            this.btnVirgula.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnVirgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVirgula.ForeColor = System.Drawing.SystemColors.Info;
            this.btnVirgula.Location = new System.Drawing.Point(71, 315);
            this.btnVirgula.Name = "btnVirgula";
            this.btnVirgula.Size = new System.Drawing.Size(75, 50);
            this.btnVirgula.TabIndex = 28;
            this.btnVirgula.Text = ",";
            this.btnVirgula.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnVirgula.UseVisualStyleBackColor = false;
            this.btnVirgula.Click += new System.EventHandler(this.btnVirgula_Click);
            // 
            // btnApagar
            // 
            this.btnApagar.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnApagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApagar.ForeColor = System.Drawing.SystemColors.Info;
            this.btnApagar.Location = new System.Drawing.Point(142, 315);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(75, 50);
            this.btnApagar.TabIndex = 30;
            this.btnApagar.Text = "⌫";
            this.btnApagar.UseVisualStyleBackColor = false;
            this.btnApagar.Click += new System.EventHandler(this.btnApagar_Click);
            // 
            // btnIgual
            // 
            this.btnIgual.BackColor = System.Drawing.Color.Red;
            this.btnIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIgual.ForeColor = System.Drawing.Color.Snow;
            this.btnIgual.Location = new System.Drawing.Point(210, 275);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(75, 90);
            this.btnIgual.TabIndex = 31;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = false;
            this.btnIgual.Click += new System.EventHandler(this.btnIgual_Click);
            // 
            // btnDivisao
            // 
            this.btnDivisao.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnDivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisao.ForeColor = System.Drawing.Color.Red;
            this.btnDivisao.Location = new System.Drawing.Point(142, 136);
            this.btnDivisao.Name = "btnDivisao";
            this.btnDivisao.Size = new System.Drawing.Size(75, 50);
            this.btnDivisao.TabIndex = 32;
            this.btnDivisao.Text = "÷";
            this.btnDivisao.UseVisualStyleBackColor = false;
            this.btnDivisao.Click += new System.EventHandler(this.btnDivisao_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.Red;
            this.btnLimpar.Location = new System.Drawing.Point(0, 136);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 50);
            this.btnLimpar.TabIndex = 33;
            this.btnLimpar.Text = "C";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnNumero1
            // 
            this.btnNumero1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero1.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero1.Location = new System.Drawing.Point(0, 183);
            this.btnNumero1.Name = "btnNumero1";
            this.btnNumero1.Size = new System.Drawing.Size(75, 50);
            this.btnNumero1.TabIndex = 34;
            this.btnNumero1.Text = "1";
            this.btnNumero1.UseVisualStyleBackColor = false;
            this.btnNumero1.Click += new System.EventHandler(this.btnNumero1_Click);
            // 
            // btnNumero9
            // 
            this.btnNumero9.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnNumero9.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumero9.ForeColor = System.Drawing.SystemColors.Info;
            this.btnNumero9.Location = new System.Drawing.Point(142, 275);
            this.btnNumero9.Name = "btnNumero9";
            this.btnNumero9.Size = new System.Drawing.Size(75, 50);
            this.btnNumero9.TabIndex = 36;
            this.btnNumero9.Text = "9";
            this.btnNumero9.UseVisualStyleBackColor = false;
            this.btnNumero9.Click += new System.EventHandler(this.btnNumero9_Click);
            // 
            // txtOperador1
            // 
            this.txtOperador1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtOperador1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOperador1.Enabled = false;
            this.txtOperador1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOperador1.Location = new System.Drawing.Point(81, 4);
            this.txtOperador1.Name = "txtOperador1";
            this.txtOperador1.Size = new System.Drawing.Size(200, 19);
            this.txtOperador1.TabIndex = 38;
            this.txtOperador1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAcao
            // 
            this.txtAcao.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtAcao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAcao.Enabled = false;
            this.txtAcao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAcao.Location = new System.Drawing.Point(81, 30);
            this.txtAcao.Name = "txtAcao";
            this.txtAcao.Size = new System.Drawing.Size(200, 19);
            this.txtAcao.TabIndex = 39;
            this.txtAcao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtOperador2
            // 
            this.txtOperador2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtOperador2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOperador2.Enabled = false;
            this.txtOperador2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOperador2.Location = new System.Drawing.Point(81, 56);
            this.txtOperador2.Name = "txtOperador2";
            this.txtOperador2.Size = new System.Drawing.Size(200, 19);
            this.txtOperador2.TabIndex = 40;
            this.txtOperador2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtIgual
            // 
            this.txtIgual.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtIgual.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIgual.Enabled = false;
            this.txtIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIgual.Location = new System.Drawing.Point(81, 82);
            this.txtIgual.Name = "txtIgual";
            this.txtIgual.Size = new System.Drawing.Size(200, 19);
            this.txtIgual.TabIndex = 41;
            this.txtIgual.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtResultado
            // 
            this.txtResultado.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtResultado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtResultado.Enabled = false;
            this.txtResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultado.Location = new System.Drawing.Point(81, 108);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(200, 19);
            this.txtResultado.TabIndex = 42;
            this.txtResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // FrmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(285, 366);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtIgual);
            this.Controls.Add(this.txtOperador2);
            this.Controls.Add(this.txtAcao);
            this.Controls.Add(this.txtOperador1);
            this.Controls.Add(this.btnNumero7);
            this.Controls.Add(this.btnNumero8);
            this.Controls.Add(this.btnNumero9);
            this.Controls.Add(this.btnNumero1);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnDivisao);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.btnVirgula);
            this.Controls.Add(this.btnNumero0);
            this.Controls.Add(this.btnNumero6);
            this.Controls.Add(this.btnNumero5);
            this.Controls.Add(this.btnNumero4);
            this.Controls.Add(this.btnNumero3);
            this.Controls.Add(this.btnNumero2);
            this.Controls.Add(this.btnAdicao);
            this.Controls.Add(this.btnSubtracao);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMultiplicacao);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmCalculadora";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.FrmCalculadora_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Button btnMultiplicacao;
        private System.Windows.Forms.Button btnSubtracao;
        private System.Windows.Forms.Button btnAdicao;
        private System.Windows.Forms.Button btnNumero2;
        private System.Windows.Forms.Button btnNumero3;
        private System.Windows.Forms.Button btnNumero4;
        private System.Windows.Forms.Button btnNumero5;
        private System.Windows.Forms.Button btnNumero6;
        private System.Windows.Forms.Button btnNumero7;
        private System.Windows.Forms.Button btnNumero0;
        private System.Windows.Forms.Button btnNumero8;
        private System.Windows.Forms.Button btnVirgula;
        private System.Windows.Forms.Button btnApagar;
        private System.Windows.Forms.Button btnIgual;
        private System.Windows.Forms.Button btnDivisao;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnNumero1;
        private System.Windows.Forms.Button btnNumero9;
        private System.Windows.Forms.TextBox txtOperador1;
        private System.Windows.Forms.TextBox txtAcao;
        private System.Windows.Forms.TextBox txtOperador2;
        private System.Windows.Forms.TextBox txtIgual;
        private System.Windows.Forms.TextBox txtResultado;
    }
}

