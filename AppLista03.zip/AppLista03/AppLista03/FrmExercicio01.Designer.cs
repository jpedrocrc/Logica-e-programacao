﻿namespace AppLista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.txtResultadoSoma = new System.Windows.Forms.TextBox();
            this.txtResultadoMedia = new System.Windows.Forms.TextBox();
            this.txtResultadoPorcentagem = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSoma
            // 
            this.btnSoma.BackColor = System.Drawing.Color.Yellow;
            this.btnSoma.Location = new System.Drawing.Point(33, 124);
            this.btnSoma.Margin = new System.Windows.Forms.Padding(6);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(150, 44);
            this.btnSoma.TabIndex = 0;
            this.btnSoma.Text = "Soma";
            this.btnSoma.UseVisualStyleBackColor = false;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.BackColor = System.Drawing.Color.Yellow;
            this.btnMedia.Location = new System.Drawing.Point(233, 124);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(6);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(150, 44);
            this.btnMedia.TabIndex = 1;
            this.btnMedia.Text = "Media";
            this.btnMedia.UseVisualStyleBackColor = false;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.BackColor = System.Drawing.Color.Yellow;
            this.btnPorcentagem.Location = new System.Drawing.Point(432, 124);
            this.btnPorcentagem.Margin = new System.Windows.Forms.Padding(6);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(150, 44);
            this.btnPorcentagem.TabIndex = 2;
            this.btnPorcentagem.Text = "Porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = false;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(13, 65);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(6);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(196, 31);
            this.txtNum1.TabIndex = 3;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(248, 65);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(6);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(196, 31);
            this.txtNum2.TabIndex = 4;
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(253, 15);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(105, 25);
            this.lblNum2.TabIndex = 5;
            this.lblNum2.Text = "Numero 2";
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(7, 15);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(105, 25);
            this.lblNum1.TabIndex = 6;
            this.lblNum1.Text = "Numero 1";
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Location = new System.Drawing.Point(486, 15);
            this.lblNum3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(105, 25);
            this.lblNum3.TabIndex = 7;
            this.lblNum3.Text = "Numero 3";
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(480, 65);
            this.txtNum3.Margin = new System.Windows.Forms.Padding(6);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(196, 31);
            this.txtNum3.TabIndex = 8;
            // 
            // txtResultadoSoma
            // 
            this.txtResultadoSoma.Location = new System.Drawing.Point(33, 204);
            this.txtResultadoSoma.Margin = new System.Windows.Forms.Padding(6);
            this.txtResultadoSoma.Name = "txtResultadoSoma";
            this.txtResultadoSoma.Size = new System.Drawing.Size(196, 31);
            this.txtResultadoSoma.TabIndex = 9;
            // 
            // txtResultadoMedia
            // 
            this.txtResultadoMedia.Location = new System.Drawing.Point(33, 259);
            this.txtResultadoMedia.Margin = new System.Windows.Forms.Padding(6);
            this.txtResultadoMedia.Name = "txtResultadoMedia";
            this.txtResultadoMedia.Size = new System.Drawing.Size(196, 31);
            this.txtResultadoMedia.TabIndex = 10;
            // 
            // txtResultadoPorcentagem
            // 
            this.txtResultadoPorcentagem.Location = new System.Drawing.Point(33, 312);
            this.txtResultadoPorcentagem.Margin = new System.Windows.Forms.Padding(6);
            this.txtResultadoPorcentagem.Name = "txtResultadoPorcentagem";
            this.txtResultadoPorcentagem.Size = new System.Drawing.Size(511, 31);
            this.txtResultadoPorcentagem.TabIndex = 11;
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(723, 435);
            this.Controls.Add(this.txtResultadoPorcentagem);
            this.Controls.Add(this.txtResultadoMedia);
            this.Controls.Add(this.txtResultadoSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FrmExercicio01";
            this.Text = "Exercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.TextBox txtResultadoSoma;
        private System.Windows.Forms.TextBox txtResultadoMedia;
        private System.Windows.Forms.TextBox txtResultadoPorcentagem;
    }
}

