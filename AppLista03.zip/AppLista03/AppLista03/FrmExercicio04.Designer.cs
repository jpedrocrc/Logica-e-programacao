﻿namespace AppLista03
{
    partial class FrmExercicio04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtAreaQuadrado = new System.Windows.Forms.TextBox();
            this.pnlResultado = new System.Windows.Forms.Panel();
            this.lblValorQuadrado = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(19, 177);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(165, 42);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular a área";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtAreaQuadrado
            // 
            this.txtAreaQuadrado.Location = new System.Drawing.Point(19, 121);
            this.txtAreaQuadrado.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtAreaQuadrado.Name = "txtAreaQuadrado";
            this.txtAreaQuadrado.Size = new System.Drawing.Size(180, 29);
            this.txtAreaQuadrado.TabIndex = 1;
            // 
            // pnlResultado
            // 
            this.pnlResultado.BackColor = System.Drawing.Color.Blue;
            this.pnlResultado.Controls.Add(this.lblResultado);
            this.pnlResultado.ForeColor = System.Drawing.Color.Gold;
            this.pnlResultado.Location = new System.Drawing.Point(3, 296);
            this.pnlResultado.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.pnlResultado.Name = "pnlResultado";
            this.pnlResultado.Size = new System.Drawing.Size(444, 158);
            this.pnlResultado.TabIndex = 2;
            // 
            // lblValorQuadrado
            // 
            this.lblValorQuadrado.AutoSize = true;
            this.lblValorQuadrado.Location = new System.Drawing.Point(15, 91);
            this.lblValorQuadrado.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblValorQuadrado.Name = "lblValorQuadrado";
            this.lblValorQuadrado.Size = new System.Drawing.Size(297, 24);
            this.lblValorQuadrado.TabIndex = 3;
            this.lblValorQuadrado.Text = "Insire o valor do lado do quadrado";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(9, 42);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 31);
            this.lblResultado.TabIndex = 0;
            // 
            // FrmExercicio04
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(445, 454);
            this.Controls.Add(this.lblValorQuadrado);
            this.Controls.Add(this.pnlResultado);
            this.Controls.Add(this.txtAreaQuadrado);
            this.Controls.Add(this.btnCalcular);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FrmExercicio04";
            this.Text = "FrmExercicio04";
            this.pnlResultado.ResumeLayout(false);
            this.pnlResultado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtAreaQuadrado;
        private System.Windows.Forms.Panel pnlResultado;
        private System.Windows.Forms.Label lblValorQuadrado;
        private System.Windows.Forms.Label lblResultado;
    }
}