﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio05 : Form
    {
        public FrmExercicio05()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valorBase = float.Parse(txtValorBase.Text);
            float valorAltura = float.Parse(txtValorAltura.Text);
            float Calcular;

           Calcular = 2*(valorBase + valorAltura);

            txtResultado.Text = Calcular.ToString();
        }
    }
}
