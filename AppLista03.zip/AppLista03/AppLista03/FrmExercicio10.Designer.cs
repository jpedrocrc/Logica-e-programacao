﻿namespace AppLista03
{
    partial class FrmExercicio10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDataNasc = new System.Windows.Forms.Label();
            this.lblAnoAtual = new System.Windows.Forms.Label();
            this.lblIdadeAno = new System.Windows.Forms.Label();
            this.lblIdadeMeses = new System.Windows.Forms.Label();
            this.lblIdadeDias = new System.Windows.Forms.Label();
            this.lblIdadeSemana = new System.Windows.Forms.Label();
            this.txtDataNascimento = new System.Windows.Forms.TextBox();
            this.txtAnoAtual = new System.Windows.Forms.TextBox();
            this.txtIdadeAnos = new System.Windows.Forms.TextBox();
            this.txtIdadeMeses = new System.Windows.Forms.TextBox();
            this.txtIdadeDias = new System.Windows.Forms.TextBox();
            this.txtIdadeSemanas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDataNasc
            // 
            this.lblDataNasc.AutoSize = true;
            this.lblDataNasc.Location = new System.Drawing.Point(15, 9);
            this.lblDataNasc.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDataNasc.Name = "lblDataNasc";
            this.lblDataNasc.Size = new System.Drawing.Size(259, 24);
            this.lblDataNasc.TabIndex = 0;
            this.lblDataNasc.Text = "Insire sua data de nascimento";
            // 
            // lblAnoAtual
            // 
            this.lblAnoAtual.AutoSize = true;
            this.lblAnoAtual.Location = new System.Drawing.Point(15, 74);
            this.lblAnoAtual.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAnoAtual.Name = "lblAnoAtual";
            this.lblAnoAtual.Size = new System.Drawing.Size(152, 24);
            this.lblAnoAtual.TabIndex = 1;
            this.lblAnoAtual.Text = "Insire o ano atual";
            // 
            // lblIdadeAno
            // 
            this.lblIdadeAno.AutoSize = true;
            this.lblIdadeAno.Location = new System.Drawing.Point(15, 231);
            this.lblIdadeAno.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblIdadeAno.Name = "lblIdadeAno";
            this.lblIdadeAno.Size = new System.Drawing.Size(138, 24);
            this.lblIdadeAno.TabIndex = 2;
            this.lblIdadeAno.Text = "Idade em Anos";
            // 
            // lblIdadeMeses
            // 
            this.lblIdadeMeses.AutoSize = true;
            this.lblIdadeMeses.Location = new System.Drawing.Point(15, 296);
            this.lblIdadeMeses.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblIdadeMeses.Name = "lblIdadeMeses";
            this.lblIdadeMeses.Size = new System.Drawing.Size(150, 24);
            this.lblIdadeMeses.TabIndex = 3;
            this.lblIdadeMeses.Text = "Idade em Meses";
            // 
            // lblIdadeDias
            // 
            this.lblIdadeDias.AutoSize = true;
            this.lblIdadeDias.Location = new System.Drawing.Point(15, 361);
            this.lblIdadeDias.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblIdadeDias.Name = "lblIdadeDias";
            this.lblIdadeDias.Size = new System.Drawing.Size(130, 24);
            this.lblIdadeDias.TabIndex = 4;
            this.lblIdadeDias.Text = "Idade em Dias";
            // 
            // lblIdadeSemana
            // 
            this.lblIdadeSemana.AutoSize = true;
            this.lblIdadeSemana.Location = new System.Drawing.Point(15, 426);
            this.lblIdadeSemana.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblIdadeSemana.Name = "lblIdadeSemana";
            this.lblIdadeSemana.Size = new System.Drawing.Size(173, 24);
            this.lblIdadeSemana.TabIndex = 5;
            this.lblIdadeSemana.Text = "Idade em Semanas";
            // 
            // txtDataNascimento
            // 
            this.txtDataNascimento.Location = new System.Drawing.Point(15, 39);
            this.txtDataNascimento.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtDataNascimento.Name = "txtDataNascimento";
            this.txtDataNascimento.Size = new System.Drawing.Size(180, 29);
            this.txtDataNascimento.TabIndex = 6;
            // 
            // txtAnoAtual
            // 
            this.txtAnoAtual.Location = new System.Drawing.Point(15, 104);
            this.txtAnoAtual.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtAnoAtual.Name = "txtAnoAtual";
            this.txtAnoAtual.Size = new System.Drawing.Size(180, 29);
            this.txtAnoAtual.TabIndex = 7;
            // 
            // txtIdadeAnos
            // 
            this.txtIdadeAnos.Location = new System.Drawing.Point(19, 261);
            this.txtIdadeAnos.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtIdadeAnos.Name = "txtIdadeAnos";
            this.txtIdadeAnos.Size = new System.Drawing.Size(180, 29);
            this.txtIdadeAnos.TabIndex = 8;
            // 
            // txtIdadeMeses
            // 
            this.txtIdadeMeses.Location = new System.Drawing.Point(19, 326);
            this.txtIdadeMeses.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtIdadeMeses.Name = "txtIdadeMeses";
            this.txtIdadeMeses.Size = new System.Drawing.Size(180, 29);
            this.txtIdadeMeses.TabIndex = 9;
            // 
            // txtIdadeDias
            // 
            this.txtIdadeDias.Location = new System.Drawing.Point(19, 391);
            this.txtIdadeDias.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtIdadeDias.Name = "txtIdadeDias";
            this.txtIdadeDias.Size = new System.Drawing.Size(180, 29);
            this.txtIdadeDias.TabIndex = 10;
            // 
            // txtIdadeSemanas
            // 
            this.txtIdadeSemanas.Location = new System.Drawing.Point(19, 456);
            this.txtIdadeSemanas.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtIdadeSemanas.Name = "txtIdadeSemanas";
            this.txtIdadeSemanas.Size = new System.Drawing.Size(180, 29);
            this.txtIdadeSemanas.TabIndex = 11;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(19, 171);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(138, 42);
            this.btnCalcular.TabIndex = 12;
            this.btnCalcular.Text = "Calcular idade";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmExercicio10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 549);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtIdadeSemanas);
            this.Controls.Add(this.txtIdadeDias);
            this.Controls.Add(this.txtIdadeMeses);
            this.Controls.Add(this.txtIdadeAnos);
            this.Controls.Add(this.txtAnoAtual);
            this.Controls.Add(this.txtDataNascimento);
            this.Controls.Add(this.lblIdadeSemana);
            this.Controls.Add(this.lblIdadeDias);
            this.Controls.Add(this.lblIdadeMeses);
            this.Controls.Add(this.lblIdadeAno);
            this.Controls.Add(this.lblAnoAtual);
            this.Controls.Add(this.lblDataNasc);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FrmExercicio10";
            this.Text = "FrmExercicio10";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDataNasc;
        private System.Windows.Forms.Label lblAnoAtual;
        private System.Windows.Forms.Label lblIdadeAno;
        private System.Windows.Forms.Label lblIdadeMeses;
        private System.Windows.Forms.Label lblIdadeDias;
        private System.Windows.Forms.Label lblIdadeSemana;
        private System.Windows.Forms.TextBox txtDataNascimento;
        private System.Windows.Forms.TextBox txtAnoAtual;
        private System.Windows.Forms.TextBox txtIdadeAnos;
        private System.Windows.Forms.TextBox txtIdadeMeses;
        private System.Windows.Forms.TextBox txtIdadeDias;
        private System.Windows.Forms.TextBox txtIdadeSemanas;
        private System.Windows.Forms.Button btnCalcular;
    }
}