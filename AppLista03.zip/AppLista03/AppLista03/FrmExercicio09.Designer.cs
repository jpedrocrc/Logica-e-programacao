﻿namespace AppLista03
{
    partial class FrmExercicio09
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMoeda1C = new System.Windows.Forms.Label();
            this.txtMoeda1C = new System.Windows.Forms.TextBox();
            this.txtMoeda5C = new System.Windows.Forms.TextBox();
            this.lblMoeda5C = new System.Windows.Forms.Label();
            this.txtMoeda10C = new System.Windows.Forms.TextBox();
            this.lblMoeda10C = new System.Windows.Forms.Label();
            this.txtMoeda25C = new System.Windows.Forms.TextBox();
            this.lblMoeda25C = new System.Windows.Forms.Label();
            this.txtMoeda50C = new System.Windows.Forms.TextBox();
            this.lblMoeda50C = new System.Windows.Forms.Label();
            this.txtMoeda1R = new System.Windows.Forms.TextBox();
            this.lblMoeda1R = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMoeda1C
            // 
            this.lblMoeda1C.AutoSize = true;
            this.lblMoeda1C.Location = new System.Drawing.Point(17, 11);
            this.lblMoeda1C.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMoeda1C.Name = "lblMoeda1C";
            this.lblMoeda1C.Size = new System.Drawing.Size(223, 25);
            this.lblMoeda1C.TabIndex = 0;
            this.lblMoeda1C.Text = "Moeda de 1 Centavos";
            // 
            // txtMoeda1C
            // 
            this.txtMoeda1C.Location = new System.Drawing.Point(263, 9);
            this.txtMoeda1C.Margin = new System.Windows.Forms.Padding(6);
            this.txtMoeda1C.Name = "txtMoeda1C";
            this.txtMoeda1C.Size = new System.Drawing.Size(196, 31);
            this.txtMoeda1C.TabIndex = 1;
            // 
            // txtMoeda5C
            // 
            this.txtMoeda5C.Location = new System.Drawing.Point(263, 65);
            this.txtMoeda5C.Margin = new System.Windows.Forms.Padding(6);
            this.txtMoeda5C.Name = "txtMoeda5C";
            this.txtMoeda5C.Size = new System.Drawing.Size(196, 31);
            this.txtMoeda5C.TabIndex = 3;
            // 
            // lblMoeda5C
            // 
            this.lblMoeda5C.AutoSize = true;
            this.lblMoeda5C.Location = new System.Drawing.Point(17, 67);
            this.lblMoeda5C.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMoeda5C.Name = "lblMoeda5C";
            this.lblMoeda5C.Size = new System.Drawing.Size(223, 25);
            this.lblMoeda5C.TabIndex = 2;
            this.lblMoeda5C.Text = "Moeda de 5 Centavos";
            // 
            // txtMoeda10C
            // 
            this.txtMoeda10C.Location = new System.Drawing.Point(263, 118);
            this.txtMoeda10C.Margin = new System.Windows.Forms.Padding(6);
            this.txtMoeda10C.Name = "txtMoeda10C";
            this.txtMoeda10C.Size = new System.Drawing.Size(196, 31);
            this.txtMoeda10C.TabIndex = 5;
            // 
            // lblMoeda10C
            // 
            this.lblMoeda10C.AutoSize = true;
            this.lblMoeda10C.Location = new System.Drawing.Point(15, 120);
            this.lblMoeda10C.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMoeda10C.Name = "lblMoeda10C";
            this.lblMoeda10C.Size = new System.Drawing.Size(235, 25);
            this.lblMoeda10C.TabIndex = 4;
            this.lblMoeda10C.Text = "Moeda de 10 Centavos";
            // 
            // txtMoeda25C
            // 
            this.txtMoeda25C.Location = new System.Drawing.Point(263, 168);
            this.txtMoeda25C.Margin = new System.Windows.Forms.Padding(6);
            this.txtMoeda25C.Name = "txtMoeda25C";
            this.txtMoeda25C.Size = new System.Drawing.Size(196, 31);
            this.txtMoeda25C.TabIndex = 7;
            // 
            // lblMoeda25C
            // 
            this.lblMoeda25C.AutoSize = true;
            this.lblMoeda25C.Location = new System.Drawing.Point(15, 168);
            this.lblMoeda25C.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMoeda25C.Name = "lblMoeda25C";
            this.lblMoeda25C.Size = new System.Drawing.Size(235, 25);
            this.lblMoeda25C.TabIndex = 6;
            this.lblMoeda25C.Text = "Moeda de 25 Centavos";
            // 
            // txtMoeda50C
            // 
            this.txtMoeda50C.Location = new System.Drawing.Point(263, 218);
            this.txtMoeda50C.Margin = new System.Windows.Forms.Padding(6);
            this.txtMoeda50C.Name = "txtMoeda50C";
            this.txtMoeda50C.Size = new System.Drawing.Size(196, 31);
            this.txtMoeda50C.TabIndex = 9;
            // 
            // lblMoeda50C
            // 
            this.lblMoeda50C.AutoSize = true;
            this.lblMoeda50C.Location = new System.Drawing.Point(17, 220);
            this.lblMoeda50C.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMoeda50C.Name = "lblMoeda50C";
            this.lblMoeda50C.Size = new System.Drawing.Size(235, 25);
            this.lblMoeda50C.TabIndex = 8;
            this.lblMoeda50C.Text = "Moeda de 50 Centavos";
            // 
            // txtMoeda1R
            // 
            this.txtMoeda1R.Location = new System.Drawing.Point(263, 268);
            this.txtMoeda1R.Margin = new System.Windows.Forms.Padding(6);
            this.txtMoeda1R.Name = "txtMoeda1R";
            this.txtMoeda1R.Size = new System.Drawing.Size(196, 31);
            this.txtMoeda1R.TabIndex = 11;
            // 
            // lblMoeda1R
            // 
            this.lblMoeda1R.AutoSize = true;
            this.lblMoeda1R.Location = new System.Drawing.Point(17, 270);
            this.lblMoeda1R.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMoeda1R.Name = "lblMoeda1R";
            this.lblMoeda1R.Size = new System.Drawing.Size(176, 25);
            this.lblMoeda1R.TabIndex = 10;
            this.lblMoeda1R.Text = "Moeda de 1 Real";
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(263, 409);
            this.txtResultado.Margin = new System.Windows.Forms.Padding(6);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(196, 31);
            this.txtResultado.TabIndex = 13;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(18, 415);
            this.lblResultado.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(175, 25);
            this.lblResultado.TabIndex = 12;
            this.lblResultado.Text = "Valor Acumulado";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(23, 320);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(436, 60);
            this.btnCalcular.TabIndex = 14;
            this.btnCalcular.Text = "Calcular o valor";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmExercicio09
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 561);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtMoeda1R);
            this.Controls.Add(this.lblMoeda1R);
            this.Controls.Add(this.txtMoeda50C);
            this.Controls.Add(this.lblMoeda50C);
            this.Controls.Add(this.txtMoeda25C);
            this.Controls.Add(this.lblMoeda25C);
            this.Controls.Add(this.txtMoeda10C);
            this.Controls.Add(this.lblMoeda10C);
            this.Controls.Add(this.txtMoeda5C);
            this.Controls.Add(this.lblMoeda5C);
            this.Controls.Add(this.txtMoeda1C);
            this.Controls.Add(this.lblMoeda1C);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FrmExercicio09";
            this.Text = "FrmExercicio09";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMoeda1C;
        private System.Windows.Forms.TextBox txtMoeda1C;
        private System.Windows.Forms.TextBox txtMoeda5C;
        private System.Windows.Forms.Label lblMoeda5C;
        private System.Windows.Forms.TextBox txtMoeda10C;
        private System.Windows.Forms.Label lblMoeda10C;
        private System.Windows.Forms.TextBox txtMoeda25C;
        private System.Windows.Forms.Label lblMoeda25C;
        private System.Windows.Forms.TextBox txtMoeda50C;
        private System.Windows.Forms.Label lblMoeda50C;
        private System.Windows.Forms.TextBox txtMoeda1R;
        private System.Windows.Forms.Label lblMoeda1R;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnCalcular;
    }
}