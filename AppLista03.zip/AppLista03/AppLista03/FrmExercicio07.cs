﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio07 : Form
    {
        public FrmExercicio07()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float camisaP = float.Parse(txtCamisaP.Text);
            float CamisaM = float.Parse(txtCamisaM.Text);
            float CamisaG = float.Parse (txtCamisaG.Text);
            float Calcular;

            Calcular = (camisaP * 12) + (CamisaM * 16) + (CamisaG * 22);

            txtResultado.Text = "R$" + Calcular.ToString() + ",00";

        }
    }
}
