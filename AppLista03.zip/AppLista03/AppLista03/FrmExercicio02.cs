﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float litro = float.Parse(txtPrecoLitro.Text);
            float pagamento = float.Parse(txtValorPagamento.Text);
            float Calcular;

            Calcular = pagamento / litro;

            txtResultado.Text = Calcular.ToString();
        }

        
    }
}
