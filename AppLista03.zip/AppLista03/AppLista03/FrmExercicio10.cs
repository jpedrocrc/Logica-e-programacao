﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio10 : Form
    {
        public FrmExercicio10()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int anoNasc = int.Parse(txtDataNascimento.Text);
            int anoAtual = int.Parse(txtAnoAtual.Text);
            //int calcularIdadeEmAnos;
            

            int idadeEmAnos = anoAtual - anoNasc;
            int idadeEmDias = idadeEmAnos * 365;
            int idadeEmMeses = idadeEmAnos * 12;
            double idadeEmSemanas = idadeEmAnos * 52.14;

            txtIdadeAnos.Text = idadeEmAnos.ToString();
            txtIdadeDias.Text = idadeEmDias.ToString();
            txtIdadeMeses.Text = idadeEmMeses.ToString();
            txtIdadeSemanas.Text = idadeEmSemanas.ToString();
            
        }
    }
}
