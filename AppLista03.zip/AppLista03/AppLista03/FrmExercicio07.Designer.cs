﻿namespace AppLista03
{
    partial class FrmExercicio07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.lblCamisaP = new System.Windows.Forms.Label();
            this.lblCamisaM = new System.Windows.Forms.Label();
            this.lblCamisaG = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCamisaP = new System.Windows.Forms.TextBox();
            this.txtCamisaM = new System.Windows.Forms.TextBox();
            this.txtCamisaG = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 172);
            this.button1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(460, 44);
            this.button1.TabIndex = 0;
            this.button1.Text = "Calcular valor arrecadado";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblCamisaP
            // 
            this.lblCamisaP.AutoSize = true;
            this.lblCamisaP.Location = new System.Drawing.Point(24, 35);
            this.lblCamisaP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCamisaP.Name = "lblCamisaP";
            this.lblCamisaP.Size = new System.Drawing.Size(262, 25);
            this.lblCamisaP.TabIndex = 1;
            this.lblCamisaP.Text = "Quantidade de Camisas P";
            // 
            // lblCamisaM
            // 
            this.lblCamisaM.AutoSize = true;
            this.lblCamisaM.Location = new System.Drawing.Point(19, 86);
            this.lblCamisaM.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCamisaM.Name = "lblCamisaM";
            this.lblCamisaM.Size = new System.Drawing.Size(266, 25);
            this.lblCamisaM.TabIndex = 2;
            this.lblCamisaM.Text = "Quantidade de Camisas M";
            // 
            // lblCamisaG
            // 
            this.lblCamisaG.AutoSize = true;
            this.lblCamisaG.Location = new System.Drawing.Point(15, 135);
            this.lblCamisaG.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCamisaG.Name = "lblCamisaG";
            this.lblCamisaG.Size = new System.Drawing.Size(264, 25);
            this.lblCamisaG.TabIndex = 3;
            this.lblCamisaG.Text = "Quantidade de Camisas G";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 234);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Valor Arrecadado";
            // 
            // txtCamisaP
            // 
            this.txtCamisaP.Location = new System.Drawing.Point(279, 35);
            this.txtCamisaP.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtCamisaP.Name = "txtCamisaP";
            this.txtCamisaP.Size = new System.Drawing.Size(196, 31);
            this.txtCamisaP.TabIndex = 5;
            // 
            // txtCamisaM
            // 
            this.txtCamisaM.Location = new System.Drawing.Point(279, 86);
            this.txtCamisaM.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtCamisaM.Name = "txtCamisaM";
            this.txtCamisaM.Size = new System.Drawing.Size(196, 31);
            this.txtCamisaM.TabIndex = 6;
            // 
            // txtCamisaG
            // 
            this.txtCamisaG.Location = new System.Drawing.Point(279, 129);
            this.txtCamisaG.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtCamisaG.Name = "txtCamisaG";
            this.txtCamisaG.Size = new System.Drawing.Size(196, 31);
            this.txtCamisaG.TabIndex = 7;
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(219, 231);
            this.txtResultado.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(196, 31);
            this.txtResultado.TabIndex = 8;
            // 
            // FrmExercicio07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 386);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtCamisaG);
            this.Controls.Add(this.txtCamisaM);
            this.Controls.Add(this.txtCamisaP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblCamisaG);
            this.Controls.Add(this.lblCamisaM);
            this.Controls.Add(this.lblCamisaP);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FrmExercicio07";
            this.Text = "FrmExercicio07";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblCamisaP;
        private System.Windows.Forms.Label lblCamisaM;
        private System.Windows.Forms.Label lblCamisaG;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCamisaP;
        private System.Windows.Forms.TextBox txtCamisaM;
        private System.Windows.Forms.TextBox txtCamisaG;
        private System.Windows.Forms.TextBox txtResultado;
    }
}