﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio09 : Form
    {
        public FrmExercicio09()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float moeda1C = float.Parse(txtMoeda1C.Text);
            float moeda5C = float.Parse(txtMoeda5C.Text);
            float moeda10C = float.Parse(txtMoeda10C.Text);
            float moeda25C = float.Parse(txtMoeda25C.Text);
            float moeda50C = float.Parse(txtMoeda50C.Text);
            float moeda1R = float.Parse(txtMoeda1R.Text);
            double Calcular;

            Calcular = (moeda1C * 0.01) + (moeda5C * 0.05) + (moeda10C * 0.10) + (moeda25C * 0.25) + (moeda50C * 0.50) + (moeda1R * 1);

            txtResultado.Text = Calcular.ToString();
        }
    }
}
