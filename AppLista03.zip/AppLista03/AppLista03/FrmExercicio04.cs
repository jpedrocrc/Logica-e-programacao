﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio04 : Form
    {
        public FrmExercicio04()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float areaQuadrado = float.Parse(txtAreaQuadrado.Text);
            float Calcular;

            Calcular = (areaQuadrado * areaQuadrado);

            lblResultado.Text = "Area do quadrado igual a " + Calcular;


        }
    }
}
