﻿namespace AppLista03
{
    partial class FrmExercicio08
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblXA = new System.Windows.Forms.Label();
            this.txtValorXa = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtValorYa = new System.Windows.Forms.TextBox();
            this.txtValorXb = new System.Windows.Forms.TextBox();
            this.txtValorYb = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblValorYA = new System.Windows.Forms.Label();
            this.lblValorXB = new System.Windows.Forms.Label();
            this.lblValorYB = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblXA
            // 
            this.lblXA.AutoSize = true;
            this.lblXA.Location = new System.Drawing.Point(15, 30);
            this.lblXA.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblXA.Name = "lblXA";
            this.lblXA.Size = new System.Drawing.Size(167, 25);
            this.lblXA.TabIndex = 0;
            this.lblXA.Text = "Insire o valor Xa";
            // 
            // txtValorXa
            // 
            this.txtValorXa.Location = new System.Drawing.Point(194, 30);
            this.txtValorXa.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtValorXa.Name = "txtValorXa";
            this.txtValorXa.Size = new System.Drawing.Size(130, 31);
            this.txtValorXa.TabIndex = 1;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(20, 220);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(306, 44);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "Calcular distância";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtValorYa
            // 
            this.txtValorYa.Location = new System.Drawing.Point(194, 73);
            this.txtValorYa.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtValorYa.Name = "txtValorYa";
            this.txtValorYa.Size = new System.Drawing.Size(130, 31);
            this.txtValorYa.TabIndex = 3;
            // 
            // txtValorXb
            // 
            this.txtValorXb.Location = new System.Drawing.Point(196, 116);
            this.txtValorXb.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtValorXb.Name = "txtValorXb";
            this.txtValorXb.Size = new System.Drawing.Size(130, 31);
            this.txtValorXb.TabIndex = 4;
            // 
            // txtValorYb
            // 
            this.txtValorYb.Location = new System.Drawing.Point(196, 158);
            this.txtValorYb.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtValorYb.Name = "txtValorYb";
            this.txtValorYb.Size = new System.Drawing.Size(130, 31);
            this.txtValorYb.TabIndex = 5;
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(194, 284);
            this.txtResultado.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(130, 31);
            this.txtResultado.TabIndex = 6;
            // 
            // lblValorYA
            // 
            this.lblValorYA.AutoSize = true;
            this.lblValorYA.Location = new System.Drawing.Point(15, 73);
            this.lblValorYA.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblValorYA.Name = "lblValorYA";
            this.lblValorYA.Size = new System.Drawing.Size(168, 25);
            this.lblValorYA.TabIndex = 8;
            this.lblValorYA.Text = "Insire o valor Ya";
            // 
            // lblValorXB
            // 
            this.lblValorXB.AutoSize = true;
            this.lblValorXB.Location = new System.Drawing.Point(15, 116);
            this.lblValorXB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblValorXB.Name = "lblValorXB";
            this.lblValorXB.Size = new System.Drawing.Size(167, 25);
            this.lblValorXB.TabIndex = 9;
            this.lblValorXB.Text = "Insire o valor Xb";
            // 
            // lblValorYB
            // 
            this.lblValorYB.AutoSize = true;
            this.lblValorYB.Location = new System.Drawing.Point(15, 161);
            this.lblValorYB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblValorYB.Name = "lblValorYB";
            this.lblValorYB.Size = new System.Drawing.Size(168, 25);
            this.lblValorYB.TabIndex = 10;
            this.lblValorYB.Text = "Insire o valor Yb";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(15, 287);
            this.lblResultado.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(131, 25);
            this.lblResultado.TabIndex = 11;
            this.lblResultado.Text = "lblResultado";
            // 
            // FrmExercicio08
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 540);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblValorYB);
            this.Controls.Add(this.lblValorXB);
            this.Controls.Add(this.lblValorYA);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtValorYb);
            this.Controls.Add(this.txtValorXb);
            this.Controls.Add(this.txtValorYa);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtValorXa);
            this.Controls.Add(this.lblXA);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FrmExercicio08";
            this.Text = "FrmExercicio08";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblXA;
        private System.Windows.Forms.TextBox txtValorXa;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtValorYa;
        private System.Windows.Forms.TextBox txtValorXb;
        private System.Windows.Forms.TextBox txtValorYb;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label lblValorYA;
        private System.Windows.Forms.Label lblValorXB;
        private System.Windows.Forms.Label lblValorYB;
        private System.Windows.Forms.Label lblResultado;
    }
}