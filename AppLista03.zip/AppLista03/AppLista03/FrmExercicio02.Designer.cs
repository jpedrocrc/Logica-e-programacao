﻿namespace AppLista03
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPrecoLitro = new System.Windows.Forms.TextBox();
            this.txtValorPagamento = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblPrecoLitro = new System.Windows.Forms.Label();
            this.lblValorPagamento = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // txtPrecoLitro
            // 
            this.txtPrecoLitro.Location = new System.Drawing.Point(171, 121);
            this.txtPrecoLitro.Margin = new System.Windows.Forms.Padding(6);
            this.txtPrecoLitro.Name = "txtPrecoLitro";
            this.txtPrecoLitro.Size = new System.Drawing.Size(180, 29);
            this.txtPrecoLitro.TabIndex = 0;
            // 
            // txtValorPagamento
            // 
            this.txtValorPagamento.Location = new System.Drawing.Point(171, 162);
            this.txtValorPagamento.Margin = new System.Windows.Forms.Padding(6);
            this.txtValorPagamento.Name = "txtValorPagamento";
            this.txtValorPagamento.Size = new System.Drawing.Size(180, 29);
            this.txtValorPagamento.TabIndex = 1;
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(171, 257);
            this.txtResultado.Margin = new System.Windows.Forms.Padding(6);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.ReadOnly = true;
            this.txtResultado.Size = new System.Drawing.Size(180, 29);
            this.txtResultado.TabIndex = 2;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(184, 203);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(138, 42);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblPrecoLitro
            // 
            this.lblPrecoLitro.AutoSize = true;
            this.lblPrecoLitro.Location = new System.Drawing.Point(15, 124);
            this.lblPrecoLitro.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPrecoLitro.Name = "lblPrecoLitro";
            this.lblPrecoLitro.Size = new System.Drawing.Size(127, 24);
            this.lblPrecoLitro.TabIndex = 4;
            this.lblPrecoLitro.Text = "Preço do Litro";
            // 
            // lblValorPagamento
            // 
            this.lblValorPagamento.AutoSize = true;
            this.lblValorPagamento.Location = new System.Drawing.Point(9, 165);
            this.lblValorPagamento.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblValorPagamento.Name = "lblValorPagamento";
            this.lblValorPagamento.Size = new System.Drawing.Size(150, 24);
            this.lblValorPagamento.TabIndex = 5;
            this.lblValorPagamento.Text = "ValorPagamento";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Location = new System.Drawing.Point(3, 329);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(560, 124);
            this.panel1.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Crimson;
            this.panel2.Location = new System.Drawing.Point(3, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(559, 89);
            this.panel2.TabIndex = 7;
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(563, 451);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblValorPagamento);
            this.Controls.Add(this.lblPrecoLitro);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtValorPagamento);
            this.Controls.Add(this.txtPrecoLitro);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FrmExercicio02";
            this.Text = "Exercicio02";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPrecoLitro;
        private System.Windows.Forms.TextBox txtValorPagamento;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblPrecoLitro;
        private System.Windows.Forms.Label lblValorPagamento;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}