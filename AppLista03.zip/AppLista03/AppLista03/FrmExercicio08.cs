﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio08 : Form
    {
        public FrmExercicio08()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double valorXa = double.Parse(txtValorXa.Text);
            double valorYa = double.Parse(txtValorYa.Text);
            double valorXb = double.Parse(txtValorXb.Text);
            double valorYb = double.Parse (txtValorYb.Text);
            double Calcular;
            double expoente = 2;


            Calcular = Math.Pow(valorXa - valorXb , expoente) + Math.Pow(valorYa - valorYb , expoente);

            txtResultado.Text = Calcular.ToString();
        }
    }
}
