﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            float operacao1 = float.Parse(txtOperacao1.Text);
            float operacao2 = float.Parse(txtOperacao2.Text);
            float soma;

            soma = operacao1 + operacao2;
            txtResultado.Text = soma.ToString();
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            float operacao1 = float.Parse(txtOperacao1.Text);
            float operacao2 = float.Parse(txtOperacao2.Text);
            float subtracao;

            subtracao = operacao1 - operacao2;
            txtResultado.Text = subtracao.ToString();
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            float operacao1 = float.Parse(txtOperacao1.Text);
            float operacao2 = float.Parse(txtOperacao2.Text);
            float multiplicacao;

            multiplicacao = operacao1 * operacao2;
            txtResultado.Text = multiplicacao.ToString();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float operacao1 = float.Parse(txtOperacao1.Text);
            float operacao2 = float.Parse(txtOperacao2.Text);
            float divisao;

            divisao = operacao1 / operacao2;
            txtResultado.Text = divisao.ToString();
        }
    }
}
